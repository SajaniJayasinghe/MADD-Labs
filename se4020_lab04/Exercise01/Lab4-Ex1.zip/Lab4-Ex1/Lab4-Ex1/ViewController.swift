//
//  ViewController.swift
//  Lab4-Ex1
//
//  Created by Sajani Jayasinghe on 2023-03-19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    


}

