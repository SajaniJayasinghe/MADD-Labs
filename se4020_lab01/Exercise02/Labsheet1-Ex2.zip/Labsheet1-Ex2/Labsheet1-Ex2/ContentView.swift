//
//  ContentView.swift
//  Labsheet1-Ex2
//
//  Created by Sajani Jayasinghe on 2023-03-03.
//

import SwiftUI

struct ContentView: View {
    @State var labelText = "Label"
    func changeLabel (){
        labelText = "Hello world"
    }
    var body: some View {
        VStack{
            Text ("\(labelText)")
                .font(.title)
                .multilineTextAlignment(.center)
                .padding(.bottom)
            
            Button(action: {
                changeLabel()
            }, label: {
                Text("Click me")
            })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
