//
//  ContentView.swift
//  Labsheet1
//
//  Created by Sajani Jayasinghe on 2023-03-02.
//

import SwiftUI

struct ContentView: View {
    @State var labelText1 : String = "Initial Value"
    var body: some View {
        VStack {
            Text(labelText1).font(.title)
            Button(action :{
                self.labelText1 = "Hello World"
            }){
                Text("Click Me")
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View{
        ContentView()
    }
}
