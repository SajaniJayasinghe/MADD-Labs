//
//  Source_CodeApp.swift
//  Labsheet1
//
//  Created by Sajani Jayasinghe on 2023-03-02.
//

import SwiftUI

@main
struct Source_CodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
