//
//  ViewController.swift
//  Lab05-Ex2
//
//  Created by Sajani Jayasinghe on 2023-04-05.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

