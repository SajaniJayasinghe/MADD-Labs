//
//  ViewController.swift
//  Lab05-Ex1
//
//  Created by Sajani Jayasinghe on 2023-04-01.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func settextButtonTapped(_ sender: UIButton) {
        if let text = textField.text{
            textLabel.text=text
        }
    }
    
    @IBAction func clearTextButtonTapped(_ sender: Any) {
        textLabel.text = ""
        textField.text = ""
    }
    
}

