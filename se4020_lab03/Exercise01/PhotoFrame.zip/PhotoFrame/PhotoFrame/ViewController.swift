//
//  ViewController.swift
//  PhotoFrame
//
//  Created by Sajani Jayasinghe on 2023-03-11.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

