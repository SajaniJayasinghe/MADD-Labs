struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        
        let lowerQuestion = question.lowercased()
        
        if !lowerQuestion.hasSuffix("?"){
            return " Is that a Question ?"
        }
        if lowerQuestion == "what is the campus?"{
            return "sliit"
        }else if lowerQuestion.hasPrefix("where"){
            return "To the North !"
        }else if lowerQuestion.hasPrefix("hello"){
            return "why hello there !"
        }else{
            let defaultNumber = question.count % 3
            
            if defaultNumber == 0{
                return "That really depends"
            }else if defaultNumber == 1{
                return " No more cookies!!"
            }else {
                return "Ask me again!"
            }
        }
    }
}
